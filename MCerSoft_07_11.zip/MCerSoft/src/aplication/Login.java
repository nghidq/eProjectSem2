/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplication;
import java.sql.Connection;
import database.DBconnect;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author David Nghi
 */
public class Login {

    String perName, admin;
    int userID, perID;

    public String username;
    public String password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPerName() {
        return perName;
    }

    public void setPerName(String perName) {
        this.perName = perName;
    }

    public String getAdmin() {
        return admin;
    }

    public void setAdmin(String admin) {
        this.admin = admin;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getPerID() {
        return perID;
    }

    public void setPerID(int perID) {
        this.perID = perID;
    }

    public ResultSet ShowLogin() throws SQLException {
        DBconnect.getConnect();
        String sql = "SELECT USERS_ID, USERNAME, PASSWORDS FROM USERS";
        return DBconnect.LoadData(sql);
    }
//Truy van cac dong du lieu trong Table theo Ma so

    public ResultSet ShowAdmin(String users, String pass) throws SQLException {
        String sql = "SELECT USERNAME, PASSWORDS FROM USERS WHERE ROLES = 1 AND"
                + " USERNAME='" + users + "' AND PASSWORDS='" + pass + "'";
        return DBconnect.LoadData(sql);
    }

    public ResultSet ShowKeeper(String users, String pass) throws SQLException {
        String sql = "SELECT USERNAME, PASSWORDS FROM USERS WHERE ROLES = 2 AND"
                + " USERNAME='" + users + "' AND PASSWORDS='" + pass + "'";
        return DBconnect.LoadData(sql);
    }
    
//Theo moi 1 dong du lieu vao table khach hang

    public void InsertData(String tenkh, String gtkh, String sdtkh, String dckh) throws SQLException {
        String sql = "INSERT INTO KHACH_HANG "
                + "values('" + tenkh + "',N'" + gtkh + "',N'" + sdtkh + "',N'" + dckh + "')";
        DBconnect.UpdateData(sql);
    }
}
