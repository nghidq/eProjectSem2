/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplication;

import database.DBconnect;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author David Nghi
 * @date 25/10/2019
 */
public class Users {
    //static Connection conn;
    //Truy van tat ca du lieu trong Table
    public ResultSet ShowUsers() throws SQLException {
        DBconnect.getConnect();
        String sql = "SELECT USERS_ID, PASSWORDS, GENDER, DOB, EMAIL FROM USERS";
        return DBconnect.LoadData(sql);
    }
//Truy van cac dong du lieu trong Table theo Ma so
    public ResultSet ShowTheoMSKH(String userid) throws SQLException {
        String sql = "SELECT * FROM USERS WHERE USERS_ID='" + userid + "'";
        return DBconnect.LoadData(sql);
    }
//Theo moi 1 dong du lieu vao table khach hang
    public void InsertData(String tenkh, String gtkh, String sdtkh, String dckh) throws SQLException {
        String sql = "INSERT INTO KHACH_HANG "
                + "values('" + tenkh + "',N'" + gtkh + "',N'" + sdtkh + "',N'" + dckh +"')";
        DBconnect.UpdateData(sql);
    }
//Dieu chinh 1 dong du lieu vao table khach hang
    public void EditData(String makh, String tenkh) throws SQLException {
        String sql = "Update  set Ten_KH=N'" + tenkh
                + "' where Ma_KH='" + makh + "'";
        DBconnect.UpdateData(sql);
    }
//Xoa 1 dong du lieu vao table khach hang
    public void DeleteData(String makh) throws SQLException {
        String sql = "Delete from KHACH_HANG where Ma_KH='" + makh + "'";
        DBconnect.UpdateData(sql);
    }
}
