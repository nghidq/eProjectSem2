/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;


import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
/**
 *
 * @author David Nghi
 */
public class DBconnect {
    static Connection conn;
    static String hostDB, dbName, accSQL, passSQL;    
    //static String dbSettingsPropertyFile = "./src/database/config.properties";
    //Phuong thuc thuc hien ket noi CSDL
    public static Connection getConnect() {
        
        try {
            readConfig();
            String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
            Class.forName(driver);
            String url = "jdbc:sqlserver://"+hostDB+";databaseName="+dbName;
            conn = DriverManager.getConnection(url, accSQL, passSQL);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            //System.out.println("Field Error");
            conn=null;
        }
        return conn;
    }
    
    public static void readConfig(){
        try {
            String cerDir = System.getProperty("user.dir");
            // Create Properties object.
            Properties props = new Properties();
            String dbSettingsPropertyFile = cerDir+"\\config.properties";
            // Properties will use a FileReader object as input.
            FileReader fReader = new FileReader(dbSettingsPropertyFile);
            // Load jdbc related properties in above file. 
            props.load(fReader);
            // Get each property value.
            String dbDriverClass = props.getProperty("db.driver.class");
            hostDB = props.getProperty("db.conn.url");            
            dbName = props.getProperty("db.dbname");
            accSQL = props.getProperty("db.username");
            passSQL = props.getProperty("db.password");
        } catch (IOException ex) {
        }
    }

//Phuong thuc dung de truy van CSDL
    public static ResultSet LoadData(String sql) {
        ResultSet result = null;
        try {
            Statement statement = conn.createStatement();
            return statement.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
//Phuong thuc thuc hien Them, Xoa, Sua du lieu
    public static void UpdateData(String sql) {
        try {
            Statement statement = conn.createStatement();
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
