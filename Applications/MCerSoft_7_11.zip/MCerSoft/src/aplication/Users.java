/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplication;

import database.DBconnect;
import java.util.Date;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author David Nghi
 * @date 25/10/2019
 */
public class Users {

    private String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public static DBconnect conn = new DBconnect();

    //Truy van tat ca du lieu trong Table
    public ResultSet ShowUsers() throws SQLException {
        //conn.getConnect();
        String sql = "SELECT USERS_ID, USERNAME, PASSWORDS, ROLES, FULLNAME, GENDER, DOB, PHONE, EMAIL, "
                + "USERS_ADD FROM USERS";
        //1 ORDER BY USERS_ID ASC
        return DBconnect.LoadData(sql);
    }
//Truy van cac dong du lieu trong Table theo Ma so

    public ResultSet ShowIDUSER(String userid) throws SQLException {
        DBconnect.getConnect();
        String sql = "SELECT * FROM USERS WHERE USERS_ID='" + userid + "'";
        return DBconnect.LoadData(sql);
    }
//Theo moi 1 dong du lieu vao table khach hang

    public void InsertData(String id, String username, String password, String fullname,
            String male, Date dob, String phone, String mail, String roles, String add) throws SQLException {
        //DBconnect.getConnect();
        String sql = "INSERT INTO USERS "
                + "VALUES('" + id + "',N'" + username + "',N'" + password + "',N'" + fullname + "',N'"
                + male + "',N'" + dob + "',N'" + phone + "',N'" + mail + "',N'" + roles + "',N'" + add + "')";
        DBconnect.UpdateData(sql);
    }
//Dieu chinh 1 dong du lieu vao table khach hang

    public void EditData(String id, String username, String password, String fullname,
            String male, Date dob, String phone, String mail, String roles, String add) throws SQLException {
        //conn.getConnect();
        String sql = "UPDATE USERS SET "+
                "USERNAME = '" + username + "',"+
                "PASWORDS = '" + password + "',"+
                "FULLNAME = '" + fullname + "',"+
                "GENDER = '" + male + "',"+
                "DOB = '" + dob + "',"+
                "PHONE = '" + phone + "'"+
                "EMAIL = '" + mail + "',"+
                "ROLES = '" + roles + "',"+
                "USERS_ADD = '" + add + "'"+
                "' WHERE USERS_ID = '" + id + "'";
        DBconnect.UpdateData(sql);
    }
//Xoa 1 dong du lieu vao table khach hang

    public void DeleteData(String id) throws SQLException {
        String sql = "DELETE FROM USERS WHERE USERS_ID ='" + id + "'";
        DBconnect.UpdateData(sql);
    }
}
